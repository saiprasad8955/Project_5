const cartModel = require("../models/cartModel")




//------------------ PLACING OR CREATING AN ORDER
const placeOrder = async (req, res) => {
    res.send({ message: "hii" })
};


//------------------ UPDATING ORDER BY ID
const updateOrderById = async (req, res) => {
    res.send({ message: "hii" })
};


module.exports = {
    placeOrder,
    updateOrderById
}